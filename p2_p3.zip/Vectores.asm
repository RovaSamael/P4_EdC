#################################################################
## Asignatura: Estructura de Computadores.
## Grado II. 2� curso.
## Fichero: Vectores.asm
## Descripci�n: Programa que...
## Fichero de apoyo: Pr�ctica: 3. Ejercicio: opcional
#################################################################


.text

main:	
	#Se guarda en s0 la direcci�n del s�mbolo N
		
	#Lee la variable N

		
	#Inicializa el bucle for

	
	#Se guarda en .. la direcci�n base del array A

	
	#Se guarda en .. la direcci�n base del array B

	
	#Se guarda en .. la direcci�n base del array C

	
	#Comprobaci�n del bucle
bucle:

	
	# C�lculo offset de los vectores
	
	
	# C�lculo de la direcci�n A(i)
	
	
	#Lectura de A(i)
	
	
	# C�lculo de la direcci�n B(i)
	
	
	#Lectura de B(i)
	
	
	#Multiplicaci�n por 4 de B(i)
	
	
	#Suma 
	
	
	# C�lculo de la direcci�n C(i)
	
	
	#Escritura en C(i)
	
	
	#Operaci�n del bucle
	
	
	#Salto a la comparaci�n
	
	
	#Bucle infinito
fin: j fin	

.data # Comienzo de seccion de memoria de datos
A: 2,2,4,6,5,6,7,8,9,10
B: -1,-5,4,10,1,-2,5,10,-10,0
C: .space 40 #.space reserva el espacio determinado en bytes.
N: 10

