---------------------------------------------------------------------
----------------------------------------------------------------------
-- Asignatura: Estructura de Computadores. GII. 2º curso.
-- Fichero: RegsRISCV.vhd
-- Descripción: Banco completo de registros del microprocesador RISC-V
-- Fichero de apoyo para: Práctica: 2. Ejercicio: 1
----------------------------------------------------------------------
----------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity RegsRISCV is
	port (
		Clk : in std_logic; -- Reloj
		NRst : in std_logic; -- Reset asíncrono a nivel bajo
		A1 : in unsigned(4 downto 0); -- Dirección para el puerto RD1
		RD1 : out signed(31 downto 0); -- Dato del puerto RD1
		A2 : in unsigned(4 downto 0); -- Dirección para el puerto RD2
		RD2 : out signed(31 downto 0); -- Dato del puerto RD2
		A3 : in unsigned(4 downto 0); -- Dirección para el puerto WD3
		WD3 : in signed(31 downto 0); -- Dato de entrada WD3
		WE3 : in std_logic -- Habilitación del banco de registros
	);
end RegsRISCV;

architecture Practica of RegsRISCV is
	
	type regs_t is array (0 to 31) of signed(31 downto 0);

	signal regs : regs_t;

begin

	process (all)
	begin
		if NRst = '0' then
			for i in 0 to 31 loop
				regs(i) <= (others => '0');
			end loop;
		elsif rising_edge(Clk) and WE3 = '1' and A3 /= "00000" then
			regs(to_integer(A3)) <= WD3;
		end if;
	end process;
			
	RD1 <= regs(to_integer(A1));

	RD2 <= regs(to_integer(A2));

end Practica;

