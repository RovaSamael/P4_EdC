#################################################################
## Asignatura: Estructura de Computadores.
## Grado II. 2� curso.
## Fichero: calculaSumaMult.asm
## Descripci�n: Programa que calcula la suma de dos operandos y posteriormente multiplica por 2, todo a trav�s de una funci�n
## Fichero de apoyo: Pr�ctica: 3. Ejercicio: 2
#################################################################

.text

main:		
	#Se guarda en s0 la direcci�n del s�mbolo X. A partir de ah� tambi�n se puede acceder f�cilmente a Y y R
	la s0, X
	
	#Lectura de X y guardado en un registro... utilice uno de los registros espec�ficos
	lw a1, 0(s0)
	
	#Lectura de Y y guardado en un registro... utilice uno de los registros espec�ficos
	lw a2, 4(s0)
	
	#Llamada a funci�n
	jal calculaSumaMult

	#Guardado del retorno en la variable R de memoria
	sw a0, 8(s0)
	
	#Bucle infinito
Bucle:  j Bucle
	

calculaSumaMult:
	
	#Suma de los dos par�metros
	add a3, a1, a2
	
	#Multiplica por dos ... utilice para el resultado final uno de los registros espec�ficos
	slli a0, a3, 1
	
	#Retorno a main
	jr ra

.data
X: 10
Y: 4
R: 
