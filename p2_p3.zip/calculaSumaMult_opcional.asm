#################################################################
## Asignatura: Estructura de Computadores.
## Grado II. 2� curso.
## Fichero: calculaSumaMult_opcional.asm
## Descripci�n: Programa que calcula la suma de dos operandos y posteriormente multiplica por 2, todo a trav�s de una funci�n
## Fichero de apoyo: Pr�ctica: 3. Ejercicio: opcional
#################################################################

.text

main:
	#Se guarda en s0 la direcci�n del s�mbolo X. A partir de ah� tambi�n se puede acceder f�cilmente a Y y R
	
	#Lectura de X y guardado en un registro
	
	#Lectura de Y y guardado en un registro
	
	#PUSH del registro equivalente a X
	
	#PUSH del registro equivalente a Y
	
	#Llamada a funci�n
	
	#Recuperaci�n del retorno mediante un POP
	
	#Guardado del retorno en la variable R de memoria
	
	#Bucle infinito
	
calculaSumaMult:
	#Recuperaci�n del segundo par�metro mediante un POP
	
	#Recuperaci�n del primer par�metro mediante un POP
	
	#Suma de los dos par�metros
	
	#Multiplica por dos
	
	#PUSH del resultado
	
	#Retorno a main

	
	

.data
X: 10
Y: 4
R:
