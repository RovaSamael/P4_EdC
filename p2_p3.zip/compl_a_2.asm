#################################################################
## Asignatura: Estructura de Computadores.
## Grado II. 2� curso.
## Fichero: compl_a_2.asm
## Descripci�n: Programa que calcula la suma de dos operandos y posteriormente multiplica por 2, todo a trav�s de una funci�n
## Fichero de apoyo: Pr�ctica: 3. Ejercicio: 3
#################################################################

.text

main:
	la s0, A

	lw a1, 0(s0)
	
	lw a2, 4(s0)

	jal funcion1
	
	sw a2, 8(s0)
	
	
Bucle:  j Bucle

funcion1:
	slli t0, a1, 2
	
	slli t1, a2, 1
	
	sub a3, t0, t1
	
	addi sp, sp, -4
	
	sw ra, 0(sp)
	
	jal compl_a_2
	
	slli a2, a2, 1
	
	lw ra, 0(sp)
	
	addi sp, sp, 4
	
	jr ra
	
compl_a_2:
	sub a2, zero, a3
	
	jr ra

.data
A: 10
B: 6
R: 