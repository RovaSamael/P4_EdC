----------------------------------------------------------------------------------
----------------------------------------------------------------------------------
-- Asignatura: Estructura de Computadores. GII. 2º curso.
-- Fichero: ALURISCV.vhd
-- Descripción: ALU del microprocesador RISC-V
-- Fichero de apoyo para: Práctica: 2. Ejercicio: 2
----------------------------------------------------------------------------------
----------------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity ALURISCV is
	port(
   		Op1 : in signed(31 downto 0);
		Op2 : in signed(31 downto 0);
		ALUControl : in std_logic_vector (2 downto 0);
		Res : out signed(31 downto 0);
		Z : out std_logic
		);
end ALURISCV;

architecture Practica of ALURISCV is

	signal res_aux : signed(31 downto 0);

begin

	process (all)
	begin
		case ALUControl is
			when "000" =>
				res_aux <= Op1 + Op2;
			when "001" =>
				res_aux <= Op1 - Op2;
			when "010" =>
				res_aux <= Op1 and Op2;
			when "011" =>
				res_aux <= Op1 or Op2;
			when "100" =>
				res_aux <= Op1 xor Op2;
			when "101" =>
				if Op1 < Op2 then
					res_aux <= x"00000001";
				else
					res_aux <= x"00000000";
				end if;
			when others =>
				res_aux <= (others => '0');
		end case;
	end process;
	
	Res <= res_aux;
	Z   <= '1' when Res = 0 else '0';

end Practica;
