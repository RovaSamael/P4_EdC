----------------------------------------------------------------------
----------------------------------------------------------------------
-- Asignatura: Estructura de Computadores. GII. 2º curso.
-- Fichero: MicroSuma.vhd
-- Descripción: Micro RISC-V muy simplificado, sólo suma con dato inmediato
-- Fichero de apoyo para: Práctica: 2. Ejercicio: 3
----------------------------------------------------------------------
----------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

entity MicroSuma is
	port (
		Clk : in std_logic; -- Reloj
		NRst : in std_logic; -- Reset activo a nivel bajo
		MemProgAddr : out unsigned(31 downto 0); -- Dirección para la memoria de programa
		MemProgData : in unsigned(31 downto 0) -- Código de operación
	);
	end MicroSuma;

architecture Practica of MicroSuma is

	component RegsRISCV 
		port (
			Clk : in std_logic; -- Reloj
			NRst : in std_logic; -- Reset asíncrono a nivel bajo
			A1 : in unsigned(4 downto 0); -- Dirección para el puerto RD1
			RD1 : out signed(31 downto 0); -- Dato del puerto RD1
			A2 : in unsigned(4 downto 0); -- Dirección para el puerto RD2
			RD2 : out signed(31 downto 0); -- Dato del puerto RD2
			A3 : in unsigned(4 downto 0); -- Dirección para el puerto WD3
			WD3 : in signed(31 downto 0); -- Dato de entrada WD3
			WE3 : in std_logic -- Habilitación del banco de registros
		);
	end component;
	
	component ALURISCV 
		port(
			Op1 : in signed(31 downto 0);
			Op2 : in signed(31 downto 0);
			ALUControl : in std_logic_vector (2 downto 0);
			Res : out signed(31 downto 0);
			Z : out std_logic
		);
	end component;
	
	signal rd1 : signed(31 downto 0);
	signal rd2 : signed(31 downto 0);
	signal alu_res : signed(31 downto 0);
	signal imm_ext : signed(31 downto 0);
	signal pc : unsigned(31 downto 0);
	signal z_unused : std_logic;

begin

	Registros: RegsRISCV
		port map (
			Clk  => Clk,
			NRst => NRst,
			A1   => MemProgData(19 downto 15),
			RD1  => rd1,
			A2   => (others => '0'),
			RD2  => rd2,
			A3   => MemProgData(11 downto 7),
			WD3  => alu_res,
			WE3  => '1'
		);
	
	ALU: ALURISCV
		port map (
			Op1        => rd1,
			Op2        => imm_ext,
			ALUControl => "000",
			Res        => alu_res,
			Z          => z_unused
		);
	
	process(all)
	begin
		if NRst = '0' then
			pc <= (others => '0');
		elsif rising_edge(Clk) then
			pc <= pc + 4;
		end if;
	end process;

	process(all)
	begin
		if MemProgData(31) = '1' then
			imm_ext <= x"FFFFF" & signed(MemProgData(31 downto 20));
		else
			imm_ext <= x"00000" & signed(MemProgData(31 downto 20));
		end if;
	end process;

	MemProgAddr <= pc;

end Practica;
